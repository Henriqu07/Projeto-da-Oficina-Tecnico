create database Mymotos;
use Mymotos;
create table cliente(
nome varchar(45),
telefone varchar(14),
email varchar(45),
Codcliente INT primary key auto_increment
) ; 

