﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace telas
{
    internal class motomodelo
    {
        public string marcamoto;
       public string modelomoto;
       public string kmmoto;
        public string cormoto;
       public int codigo;
        public int cod_cliente;
        public motomodelo()
        {
            this.marcamoto = marcamoto;
            this.modelomoto = modelomoto;
            this.kmmoto = kmmoto;
            this.cormoto = cormoto;
            this.codigo = codigo;
        }
    }
}
