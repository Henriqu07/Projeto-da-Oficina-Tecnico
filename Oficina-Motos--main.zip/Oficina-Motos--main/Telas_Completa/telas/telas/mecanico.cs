﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace telas
{
    internal class cadastromecanico
    {
        public int cod_mecanico;
        public string nomeoficina;
        public string nomemecanico;
        public string emailmecanico;
        public string senhamecanico;

        public cadastromecanico()
        {
            nomeoficina = "";
            nomemecanico = "";
            emailmecanico = "";
            senhamecanico = "";
        }

            
    }
}
